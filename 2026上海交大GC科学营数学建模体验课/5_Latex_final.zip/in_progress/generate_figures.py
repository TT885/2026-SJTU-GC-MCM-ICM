# -*- coding: utf-8 -*-
"""
从 4_编程作图演示.ipynb 提取的作图逻辑复现脚本。
用真实数据重跑 notebook 中的全部 7 张图，保存到 figure/ 目录。

数据：10-22本次授课材料准备/2025_Problem_C_Data
输出：10-22本次授课材料准备/in_progress/figure/fig1..fig7_*.png
"""
import os
import re
import numpy as np
import matplotlib
matplotlib.use("Agg")  # 无界面后端，纯导出图片
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import mean_squared_error, r2_score

BASE = "/Users/zhangjiale101/Desktop/D/00-Repository/04-Scholar/05-Laboratory(ANL-DCE)/05_Presentations/2026-10-24数学建模培训"
DATA = os.path.join(BASE, "10-22本次授课材料准备", "2025_Problem_C_Data")
FIGDIR = os.path.join(BASE, "10-22本次授课材料准备", "in_progress", "figure")
os.makedirs(FIGDIR, exist_ok=True)

plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 110
plt.rcParams["savefig.dpi"] = 110

# ---------- 读数据 ----------
mc = pd.read_csv(os.path.join(DATA, "summerOly_medal_counts.csv"))
ath = pd.read_csv(os.path.join(DATA, "summerOly_athletes.csv"),
                  usecols=["Year", "NOC", "Team", "Sport", "Event", "Medal"])
prog = pd.read_csv(os.path.join(DATA, "summerOly_programs.csv"), encoding="latin-1")

clean_name = lambda s: str(s).replace("\xa0", " ").strip()
def clean(s):
    return re.sub(r"-\d+$", "", str(s).replace("\xa0", " ")).strip()

# ---------- FIG 1: 中美金牌趋势 ----------
mc2 = mc.copy()
mc2["NOC"] = mc2.NOC.map(clean_name)
fig, ax = plt.subplots(figsize=(9.5, 3.9))
for name, color in [("United States", "#c0392b"), ("China", "#f39c12")]:
    d = mc2[mc2.NOC == name].groupby("Year")["Gold"].sum()
    ax.plot(d.index, d.values, marker="o", ms=3.5, lw=2, color=color, label=name)
ax.set_title("Fig1. US vs China: gold medals by Games (1896-2024)", fontsize=12.5)
ax.set_xlabel("Year"); ax.set_ylabel("Gold medals")
ax.legend(fontsize=10); ax.grid(alpha=.3)
plt.tight_layout(); plt.savefig(os.path.join(FIGDIR, "fig1_medal_trend.png")); plt.close()

# ---------- FIG 2: 历届小项总数 ----------
year_cols = [c for c in prog.columns if c[:4].isdigit()]
ev_all = prog[year_cols].apply(pd.to_numeric, errors="coerce")
ev_all = ev_all[~prog.Sport.astype(str).str.startswith("Total")]
tot_by_year = ev_all.sum().values
yrs = [int(str(c).rstrip("*")) for c in year_cols]

fig, ax = plt.subplots(figsize=(9.5, 4.0))
ax.plot(yrs, tot_by_year, marker="o", ms=3.5, lw=1.8, color="#2980b9")
ax.scatter([2024], [tot_by_year[-1]], s=90, c="#c0392b", zorder=5)
i0, i1, i2 = yrs.index(1896), yrs.index(2020), yrs.index(2024)
ax.annotate(f"1896: {int(tot_by_year[i0])}", xy=(1896, tot_by_year[i0]),
            xytext=(6, -16), textcoords="offset points", fontsize=9.5)
ax.annotate(f"2020: {int(tot_by_year[i1])}", xy=(2020, tot_by_year[i1]),
            xytext=(-34, 10), textcoords="offset points", fontsize=9.5)
ax.annotate(f"2024: {int(tot_by_year[i2])}", xy=(2024, tot_by_year[i2]),
            xytext=(-16, -46), textcoords="offset points", fontsize=9.5, color="#c0392b",
            ha="right", bbox=dict(fc="white", ec="none", alpha=.85, pad=1.5))
ax.set_xlim(1888, 2032); ax.set_ylim(0, max(tot_by_year) * 1.18)
ax.annotate("2028 = ?\n(not in data)", xy=(2028, max(tot_by_year) * 0.55),
            fontsize=10.5, color="#c0392b", ha="center")
ax.set_title("Fig2. Total events by Games: not monotonic, 2028 must be predicted", fontsize=12.5)
ax.set_xlabel("Year"); ax.set_ylabel("Number of events")
ax.grid(alpha=.3)
plt.tight_layout(); plt.savefig(os.path.join(FIGDIR, "fig2_events_by_year.png")); plt.close()

# ---------- 建模准备 ----------
YEAR_COLS = [c for c in prog.columns if c[:4].isdigit()]
YEARS = np.array([int(str(c).rstrip("*")) for c in YEAR_COLS], float)
is_total = prog.Sport.astype(str).str.startswith("Total")
DIS = prog[~is_total].reset_index(drop=True)

def series_of(code):
    v = pd.to_numeric(DIS.loc[DIS.Code == code, YEAR_COLS].iloc[0], errors="coerce").values
    return np.nan_to_num(v)

gar = series_of("GAR")

def svr_forecast(vals, random_state=42):
    X = YEARS.reshape(-1, 1)
    y = vals.astype(float)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=random_state)
    sx = StandardScaler().fit(X_tr)
    sy = StandardScaler().fit(y_tr.reshape(-1, 1))
    grid = {"C": [1, 10, 100, 1000], "gamma": ["scale", 0.01, 0.1, 1],
            "epsilon": [0.01, 0.1, 0.5]}
    gs = GridSearchCV(SVR(kernel="rbf"), grid, cv=5, scoring="neg_mean_squared_error")
    gs.fit(sx.transform(X_tr), sy.transform(y_tr.reshape(-1, 1)).ravel())
    pred_te = sy.inverse_transform(gs.predict(sx.transform(X_te)).reshape(-1, 1)).ravel()
    mse = mean_squared_error(y_te, pred_te)
    r2 = r2_score(y_te, pred_te)
    p2028 = float(sy.inverse_transform(gs.predict(sx.transform([[2028.0]])).reshape(-1, 1))[0, 0])
    return p2028, mse, r2, gs.best_params_, (gs.best_estimator_, sx, sy)

p_gar, mse_gar, r2_gar, best_gar, fitted_gar = svr_forecast(gar)

# 全部分项预测
rows = []
for _, r in DIS.iterrows():
    v = pd.to_numeric(r[YEAR_COLS], errors="coerce").values
    if np.all(np.isnan(v)):
        continue
    v = np.nan_to_num(v)
    p28, m, r2v, bp, _ = svr_forecast(v)
    rows.append({"Sport": r.Sport, "Discipline": r.Discipline, "Code": r.Code,
                 "Y2024": int(v[-1]), "Y2028": float(np.clip(p28, 0, None)),
                 "MSE": m, "R2": r2v})
PRED = pd.DataFrame(rows)
PRED["Y2028"] = PRED.Y2028.round().astype(int)

print("建模分项数:", len(PRED))
print("2024 实际项目总数:", int(PRED.Y2024.sum()))
print("2028 预测项目总数:", int(PRED.Y2028.sum()))
print("GAR 2028 ->", round(p_gar, 2), "| MSE", round(mse_gar,3), "| R2", round(r2_gar,3))

# ---------- FIG 3: 变化最大的分项 2024 vs 2028 ----------
by_sport = PRED.groupby("Sport")[["Y2024", "Y2028"]].sum()
by_sport["变化"] = by_sport.Y2028 - by_sport.Y2024
top = by_sport.reindex(by_sport["变化"].abs().sort_values(ascending=False).index).head(8)
ypos = np.arange(len(top))
fig, ax = plt.subplots(figsize=(9.5, 4.4))
ax.barh(ypos + 0.19, top.Y2024, height=.38, color="#95a5a6", label="2024 actual")
ax.barh(ypos - 0.19, top.Y2028, height=.38, color="#c0392b", label="2028 predicted")
ax.set_yticks(ypos); ax.set_yticklabels(list(top.index), fontsize=10)
ax.invert_yaxis()
ax.set_title("Fig3. Biggest movers: 2024 actual vs 2028 predicted", fontsize=12.5)
ax.set_xlabel("Number of events")
ax.legend(fontsize=10, loc="lower right"); ax.grid(alpha=.3, axis="x")
plt.tight_layout(); plt.savefig(os.path.join(FIGDIR, "fig3_change_2028.png")); plt.close()

# ---------- FIG 4: 滑板序列 ----------
bad = PRED[(PRED.Y2024 > 0) & (PRED.Y2028 == 0)]
skb = series_of("SKB")
n_zero = int((skb == 0).sum())
fig, ax = plt.subplots(figsize=(9.5, 3.8))
ax.bar(YEARS, skb, width=2.6, color=["#c0392b" if v > 0 else "#bdc3c7" for v in skb])
ax.annotate("entered the Games only in 2020",
            xy=(2019.6, 4.05), xytext=(1978, 6.0), fontsize=9.5, color="#c0392b",
            arrowprops=dict(arrowstyle="->", color="#c0392b", lw=1.3))
ax.set_ylim(0, 8)
ax.set_title(f"Fig4. Skateboarding (SKB): {n_zero} of 31 Games are zero", fontsize=12.5)
ax.set_xlabel("Year"); ax.set_ylabel("Number of events")
ax.grid(alpha=.3, axis="y")
plt.tight_layout(); plt.savefig(os.path.join(FIGDIR, "fig4_skb_zero.png")); plt.close()

# ---------- FIG 5: 艺术体操 SVR 拟合 + 外推 ----------
model, sx, sy = fitted_gar
gx = np.linspace(YEARS.min(), 2028, 400).reshape(-1, 1)
gy = sy.inverse_transform(model.predict(sx.transform(gx)).reshape(-1, 1)).ravel()
fig, ax = plt.subplots(figsize=(9.5, 4.3))
ax.scatter(YEARS, gar, s=26, c="#2980b9", alpha=.75, zorder=3, label="Historical")
ax.plot(gx.ravel(), gy, color="#c0392b", lw=2, zorder=2, label="SVR fit")
ax.scatter([2028], [p_gar], s=170, marker="*", c="#f39c12", edgecolor="black", zorder=5,
           label=f"2028 forecast {p_gar:.1f}")
ax.axvline(2024, color="#7f8c8d", ls=":", lw=1.2)
ax.annotate("history  |  extrapolation ->", xy=(2022.5, max(gar) * 0.28),
            fontsize=9, color="#7f8c8d", ha="right")
ax.set_title(f"Fig5. Artistic gymnastics: history and 2028 forecast "
             f"(MSE={mse_gar:.2f}, R2={r2_gar:.2f})", fontsize=12.5)
ax.set_xlabel("Year"); ax.set_ylabel("Number of events")
ax.legend(loc="lower right", fontsize=9); ax.grid(alpha=.3)
plt.tight_layout(); plt.savefig(os.path.join(FIGDIR, "fig5_svr_events.png")); plt.close()

# ---------- 2024 加权得分 ----------
m24 = ath[(ath.Year == 2024) & (ath.Medal != "No medal")].copy()
m24["Team"] = m24.Team.map(lambda s: re.sub(r"-\d+$", "", str(s)).strip())
uniq = m24.drop_duplicates(["Team", "Sport", "Event", "Medal"]).copy()
uniq["w"] = uniq.Medal.map({"Gold": 3, "Silver": 2, "Bronze": 1})
score = uniq.groupby(["Team", "Sport"])["w"].sum().reset_index()
total = score.groupby("Team")["w"].sum()
score["占比"] = score.w / score.Team.map(total)

# ---------- FIG 6: Top10 加权得分堆叠 ----------
cnt = (uniq.groupby(["Team", "Medal"]).size()
           .unstack(fill_value=0)
           .reindex(columns=["Gold", "Silver", "Bronze"], fill_value=0))
part = pd.DataFrame({"gold": cnt["Gold"] * 3,
                     "silver": cnt["Silver"] * 2,
                     "bronze": cnt["Bronze"] * 1})
part["S"] = part.sum(axis=1)
top10 = part.nlargest(10, "S")
fig, ax = plt.subplots(figsize=(9.5, 4.6))
left = np.zeros(len(top10))
for col, color, lab in [("gold", "#f1c40f", "Gold x3"),
                        ("silver", "#bdc3c7", "Silver x2"),
                        ("bronze", "#cd7f32", "Bronze x1")]:
    ax.barh(range(len(top10)), top10[col], left=left, color=color, label=lab,
            edgecolor="white", lw=.5)
    left = left + top10[col].values
ax.set_yticks(range(len(top10)))
ax.set_yticklabels(list(top10.index), fontsize=10)
ax.invert_yaxis()
for i, v in enumerate(top10.S):
    ax.text(v + 4, i, str(int(v)), va="center", fontsize=9.5)
ax.set_xlim(0, top10.S.max() * 1.14)
ax.set_title("Fig6. Weighted score S = 3*gold + 2*silver + 1*bronze, 2024 (Top 10)", fontsize=12.5)
ax.set_xlabel("Weighted score S")
ax.legend(fontsize=10, loc="lower right"); ax.grid(alpha=.3, axis="x")
plt.tight_layout(); plt.savefig(os.path.join(FIGDIR, "fig6_country_score.png")); plt.close()

# ---------- FIG 7: 重要性热力图 ----------
top6 = total.nlargest(6).index.tolist()
piv = (score[score.Team.isin(top6)]
       .pivot(index="Team", columns="Sport", values="占比")
       .fillna(0).loc[top6])
keep = piv.sum().nlargest(10).index
piv = piv[keep] * 100
fig, ax = plt.subplots(figsize=(10.5, 4.4))
im = ax.imshow(piv.values, cmap="YlOrRd", aspect="auto", vmin=0)
ax.set_xticks(range(len(keep)))
ax.set_xticklabels(list(keep), rotation=30, ha="right", fontsize=9.5)
ax.set_yticks(range(len(top6)))
ax.set_yticklabels(list(top6), fontsize=10)
for i in range(piv.shape[0]):
    for j in range(piv.shape[1]):
        v = piv.values[i, j]
        if v >= 1:
            ax.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=8.5,
                    color="white" if v >= 20 else "#2c3e50")
ax.set_title("Fig7. Share of each country's weighted score by sport, 2024 (%)", fontsize=12.5)
plt.colorbar(im, ax=ax, shrink=.85, label="share (%)")
plt.tight_layout(); plt.savefig(os.path.join(FIGDIR, "fig7_sport_share.png")); plt.close()

print("\n全部 7 张图已生成于:", FIGDIR)
import glob
for f in sorted(glob.glob(os.path.join(FIGDIR, "*.png"))):
    print("  ", os.path.basename(f), f"{os.path.getsize(f)/1024:.1f} KB")

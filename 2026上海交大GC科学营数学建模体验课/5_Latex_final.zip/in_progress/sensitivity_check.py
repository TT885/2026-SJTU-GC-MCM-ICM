# -*- coding: utf-8 -*-
"""为 06-sensitivity.tex 计算 GAR 的敏感性数字（仅艺术体操单序列，速度很快）。"""
import os, re, json
import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error

BASE = "/Users/zhangjiale101/Desktop/D/00-Repository/04-Scholar/05-Laboratory(ANL-DCE)/05_Presentations/2026-10-24数学建模培训"
DATA = os.path.join(BASE, "10-22本次授课材料准备", "2025_Problem_C_Data")
prog = pd.read_csv(os.path.join(DATA, "summerOly_programs.csv"), encoding="latin-1")

YEAR_COLS = [c for c in prog.columns if c[:4].isdigit()]
YEARS = np.array([int(str(c).rstrip("*")) for c in YEAR_COLS], float)
is_total = prog.Sport.astype(str).str.startswith("Total")
DIS = prog[~is_total].reset_index(drop=True)
gar = np.nan_to_num(pd.to_numeric(DIS.loc[DIS.Code == "GAR", YEAR_COLS].iloc[0], errors="coerce").values)

def forecast(vals, C, gamma, eps, kernel="rbf", rs=42):
    X = YEARS.reshape(-1, 1); y = vals.astype(float)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=rs)
    sx = StandardScaler().fit(X_tr); sy = StandardScaler().fit(y_tr.reshape(-1,1))
    svr = SVR(kernel=kernel, C=C, gamma=gamma, epsilon=eps)
    svr.fit(sx.transform(X_tr), sy.transform(y_tr.reshape(-1,1)).ravel())
    pred_te = sy.inverse_transform(svr.predict(sx.transform(X_te)).reshape(-1,1)).ravel()
    mae = mean_absolute_error(y_te, pred_te)
    p2028 = float(sy.inverse_transform(svr.predict(sx.transform([[2028.0]])).reshape(-1,1))[0,0])
    return p2028, mae

print("=== GAR 2028 预测对超参数的敏感性 (8:2 随机切分, rs=42) ===")
print(f"{'C':>6} {'gamma':>8} {'epsilon':>8} {'forecast':>10} {'MAE':>8}")
rows = []
for C in [1, 10, 100, 1000]:
    for gamma in ["scale", 0.01, 0.1, 1]:
        for eps in [0.01, 0.1, 0.5]:
            p, mae = forecast(gar, C, gamma, eps)
            rows.append((C, gamma, eps, round(p,3), round(mae,3)))
            if (C, gamma, eps) in [(10,0.1,0.1),(10,"scale",0.1),(100,0.1,0.1)]:
                print(f"{C:>6} {str(gamma):>8} {eps:>8} {p:>10.3f} {mae:>8.3f}")
print(f"所有组合预测范围: {min(r[3] for r in rows):.2f} ~ {max(r[3] for r in rows):.2f} 项")

print("\n=== GAR 2028 预测对随机种子(切分)的敏感性 ===")
for rs in [0, 21, 42, 123, 999]:
    p, mae = forecast(gar, 10, 0.1, 0.1, rs=rs)
    print(f"  rs={rs:>4}: forecast={p:.3f}, MAE={mae:.3f}")

print("\n=== 核函数对比 (C=10, gamma=scale, eps=0.1) ===")
for k in ["rbf", "linear", "poly", "sigmoid"]:
    try:
        p, mae = forecast(gar, 10, "scale", 0.1, kernel=k)
        print(f"  {k:>8}: forecast={p:.3f}, MAE={mae:.3f}")
    except Exception as e:
        print(f"  {k:>8}: failed ({e})")

print("\n=== 时间轴切分(前24训练 / 后6检验) 的 GAR 表现 ===")
# 前 24 个版本(1896 起)训练，后 6 个版本(2000-2024)检验
X = YEARS.reshape(-1,1); y = gar.astype(float)
n = len(YEARS)
X_tr, y_tr = X[:24], y[:24]
X_te, y_te = X[24:], y[24:]
sx = StandardScaler().fit(X_tr); sy = StandardScaler().fit(y_tr.reshape(-1,1))
svr = SVR(kernel="rbf", C=10, gamma="scale", epsilon=0.1)
svr.fit(sx.transform(X_tr), sy.transform(y_tr.reshape(-1,1)).ravel())
pred_te = sy.inverse_transform(svr.predict(sx.transform(X_te)).reshape(-1,1)).ravel()
mae = mean_absolute_error(y_te, pred_te)
mse = mean_squared_error(y_te, pred_te)
rmse = mse**0.5
print(f"  检验集年份: {[int(v) for v in YEARS[24:]]}")
print(f"  真实值: {[int(v) for v in y_te]}")
print(f"  预测值: {[round(v,2) for v in pred_te]}")
print(f"  MAE={mae:.3f}, MSE={mse:.3f}, RMSE={rmse:.3f}")
# 全量重训推 2028
sx2 = StandardScaler().fit(X); sy2 = StandardScaler().fit(y.reshape(-1,1))
svr2 = SVR(kernel="rbf", C=10, gamma="scale", epsilon=0.1)
svr2.fit(sx2.transform(X), sy2.transform(y.reshape(-1,1)).ravel())
p2028 = float(sy2.inverse_transform(svr2.predict(sx2.transform([[2028.0]])).reshape(-1,1))[0,0])
print(f"  全量重训 2028 点估计: {p2028:.3f} -> 显示为 {round(p2028)} 项")

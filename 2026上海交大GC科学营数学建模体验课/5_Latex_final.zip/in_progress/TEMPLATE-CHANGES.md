# 模板来源与必要修改

底层 easymcm-course.sty **通常不需要修改**。本课程衍生自用户提供的 QTH1225/LaTeX-in-ICM-MCM Template/easymcm2.sty 和 main.tex；保留原 EasyMCM 作者、QTH1225 维护说明与 LPPL 1.3c。不是上游官方版本，上游作者不承担本课支持责任。

完整未修改上游：https://github.com/QTH1225/LaTeX-in-ICM-MCM 。此前查询远程 main 提交为 0906a360588846bdf2aa9b09c413581a0bee7b7e；本地下载快照缺 .git，不声称它与该提交完全相同。本地原文件哈希见仓库 data/source-manifest.json。

沿用上一版的样式改名、编译标识、拼写修正 breakatwhitespace=true、教学页眉、2025赛题年份和非参赛控制号声明；保留 12pt article、Palatino、Summary Sheet、AMS数学、booktabs、graphicx、hyperref。删掉无关装饰、代码示例、复杂盒子和强制空白页。

本次（2026-10-22）只再调整：
- 修改样式自报版本为 modified course edition v1.1；目录仍自动生成，但不再单独强制占一页，目录后连续排正文；适度收紧标题和段间距，保留12pt正文。
- main.tex 仅设置与 input；正文按 sections/ 拆分。移除空的 new_command.tex、旧 part 文件、stage-model、自动表格 input。无新自定义命令、无 shell escape、无 BibTeX 步骤。
- 三张教学图预放入两版 figures/，参考章节可单独替换。表格直接写在相应章节中，按 CSV 人工核对。
- 各章节开头中文注释说明作用、修改处和依赖；注释不出现在英文 PDF 中。

许可全文随包 LPPL-1.3c.txt；更多教学说明只在课程 docs/teacher-notes.md。
